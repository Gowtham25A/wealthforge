import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './features/auth/login/login.component';
import { RegisterComponent } from './features/auth/register/register.component';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { PortfoliosComponent } from './features/investor/portfolios/portfolios.component';
import { PortfolioDetailComponent } from './features/investor/portfolio-detail/portfolio-detail.component';
import { TransactionsComponent } from './features/investor/transactions/transactions.component';
import { GoalsComponent } from './features/investor/goals/goals.component';
import { ReportsComponent } from './features/investor/reports/reports.component';
import { MessagesComponent } from './features/messages/messages.component';
import { AdminDashboardComponent } from './features/admin/admin-dashboard/admin-dashboard.component';
import { AdvisorDashboardComponent } from './features/advisor/advisor-dashboard/advisor-dashboard.component';
import { AuthGuard } from './core/guards/auth.guard';
import { RoleGuard } from './core/guards/role.guard';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'portfolios',
    component: PortfoliosComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['INVESTOR'] }
  },
  {
    path: 'portfolios/:id',
    component: PortfolioDetailComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['INVESTOR'] }
  },
  {
    path: 'transactions',
    component: TransactionsComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['INVESTOR'] }
  },
  {
    path: 'goals',
    component: GoalsComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['INVESTOR'] }
  },
  {
    path: 'reports',
    component: ReportsComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['INVESTOR'] }
  },
  {
    path: 'messages',
    component: MessagesComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'admin',
    component: AdminDashboardComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['ADMIN'] }
  },
  {
    path: 'advisor',
    component: AdvisorDashboardComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['ADVISOR'] }
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
