import { Component } from '@angular/core';
import { AuthService } from '../../../../app/core/services/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {
  user = null;
  constructor(private authService: AuthService) {
    this.user = this.authService.getCurrentUser();
  }
}
