import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PortfolioService } from '../../../core/services/portfolio.service';

@Component({
  selector: 'app-portfolio-detail',
  templateUrl: './portfolio-detail.component.html',
  styleUrls: ['./portfolio-detail.component.scss']
})
export class PortfolioDetailComponent implements OnInit {
  portfolioId!: number;
  portfolio: any = null;
  loading = false;

  constructor(private route: ActivatedRoute, private portfolioService: PortfolioService) {}

  ngOnInit(): void {
    this.portfolioId = Number(this.route.snapshot.paramMap.get('id'));
    this.load();
  }

  load() {
    this.loading = true;
    // placeholder call — depends on backend route. Using getPortfolios then find as fallback.
    this.portfolioService.getPortfolios().subscribe({
      next: (res) => {
        this.portfolio = res.find((p: any) => p.id === this.portfolioId) || null;
        this.loading = false;
      },
      error: () => { this.loading = false; }
    });
  }
}
