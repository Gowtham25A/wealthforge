import { Component } from '@angular/core';

@Component({
  selector: 'app-goals',
  templateUrl: './goals.component.html',
  styleUrls: ['./goals.component.scss']
})
export class GoalsComponent {
  goals = [
    { id: 1, title: 'Retirement', target: '2040', amount: 1000000 }
  ];
}
