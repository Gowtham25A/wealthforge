import { Component, OnInit } from '@angular/core';
import { PortfolioService } from '../../../core/services/portfolio.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-portfolios',
  templateUrl: './portfolios.component.html',
  styleUrls: ['./portfolios.component.scss']
})
export class PortfoliosComponent implements OnInit {
  portfolios: any[] = [];
  loading = false;
  error = '';

  constructor(private portfolioService: PortfolioService, private router: Router) {}

  ngOnInit(): void {
    this.loading = true;
    this.portfolioService.getPortfolios().subscribe({
      next: (res) => { this.portfolios = res; this.loading = false; },
      error: (err) => { this.error = 'Failed to load portfolios'; this.loading = false; }
    });
  }

  openPortfolio(id: number) {
    this.router.navigate(['/portfolios', id]);
  }
}
