import { Component, OnInit } from '@angular/core';
import { PortfolioService } from '../../../core/services/portfolio.service';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.scss']
})
export class TransactionsComponent implements OnInit {
  transactions: any[] = [];
  loading = false;

  constructor(private portfolioService: PortfolioService) {}

  ngOnInit(): void {
    this.loading = true;
    // No dedicated endpoint in sample; placeholder
    this.portfolioService.getPortfolios().subscribe({
      next: () => { this.transactions = []; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }
}
