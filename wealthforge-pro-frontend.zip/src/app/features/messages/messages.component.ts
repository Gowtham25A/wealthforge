import { Component } from '@angular/core';

@Component({
  selector: 'app-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.scss']
})
export class MessagesComponent {
  messages = [
    { id: 1, from: 'advisor@bank.com', subject: 'Portfolio review' }
  ];
}
