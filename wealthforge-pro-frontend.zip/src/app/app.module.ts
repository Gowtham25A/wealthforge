import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

// Interceptors
import { AuthInterceptor } from './core/interceptors/auth.interceptor';

// Components
import { LoginComponent } from './features/auth/login/login.component';
import { RegisterComponent } from './features/auth/register/register.component';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { PortfoliosComponent } from './features/investor/portfolios/portfolios.component';
import { PortfolioDetailComponent } from './features/investor/portfolio-detail/portfolio-detail.component';
import { TransactionsComponent } from './features/investor/transactions/transactions.component';
import { GoalsComponent } from './features/investor/goals/goals.component';
import { ReportsComponent } from './features/investor/reports/reports.component';
import { MessagesComponent } from './features/messages/messages.component';
import { AdminDashboardComponent } from './features/admin/admin-dashboard/admin-dashboard.component';
import { AdvisorDashboardComponent } from './features/advisor/advisor-dashboard/advisor-dashboard.component';
import { NavbarComponent } from './shared/components/navbar/navbar.component';
import { SidebarComponent } from './shared/components/sidebar/sidebar.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    DashboardComponent,
    PortfoliosComponent,
    PortfolioDetailComponent,
    TransactionsComponent,
    GoalsComponent,
    ReportsComponent,
    MessagesComponent,
    AdminDashboardComponent,
    AdvisorDashboardComponent,
    NavbarComponent,
    SidebarComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
