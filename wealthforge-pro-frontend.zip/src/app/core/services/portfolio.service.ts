import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PortfolioService {
  private apiUrl = 'http://localhost:8080/api/investor';

  constructor(private http: HttpClient) { }

  getPortfolios(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/portfolios`, { withCredentials: true });
  }

  createPortfolio(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/portfolios`, data, { withCredentials: true });
  }

  addAsset(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/assets`, data, { withCredentials: true });
  }

  addTransaction(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/transactions`, data, { withCredentials: true });
  }

  updateTransaction(id: number, data: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/transactions/${id}`, data, { withCredentials: true });
  }

  deleteTransaction(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/transactions/${id}`, { withCredentials: true });
  }

  getAllocation(portfolioId: number): Observable<any> {
    return this.http.get(`http://localhost:8080/api/investor/analytics/allocation/${portfolioId}`, { withCredentials: true });
  }

  getReturns(portfolioId: number, period: string = 'daily'): Observable<any> {
    return this.http.get(`http://localhost:8080/api/investor/analytics/returns/${portfolioId}?period=${period}`, { withCredentials: true });
  }
}
